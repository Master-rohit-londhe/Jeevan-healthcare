﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Signup : System.Web.UI.Page
{
    string cs;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       
        cs = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True;User Instance=True";
        SqlConnection cn = new SqlConnection(cs);
        cn.Open();
        SqlCommand cmd = new SqlCommand("Insert into Signupdetail(Username,Password)values(@unm,@upwd)", cn);
        cmd.Parameters.AddWithValue("@unm", T1.Text);
        cmd.Parameters.AddWithValue("@upwd", T2.Text);
        cmd.ExecuteNonQuery();
        //Response.Redirect("home.aspx");
        SqlDataAdapter da = new SqlDataAdapter("Select Username,Password from login where Username='" + T1.Text + "' and Password='" + T2.Text + "'", cn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count==0)
         {

            Label2.Text = "Sorry User Details are wrong";
          }
        else
          {
                  Response.Redirect("home.aspx");
          }
      }
    
}