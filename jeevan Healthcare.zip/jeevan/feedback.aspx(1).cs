﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class feedback : System.Web.UI.Page
{
    string cs;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Label1.Text = "";
        cs = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True;User Instance=True";

        SqlConnection cn = new SqlConnection(cs);
        cn.Open();
        SqlCommand cmd = new SqlCommand("Insert into Feedback(UserName,Contact,EMail,UFeedback)values(@unm,@uc,@em,@um)", cn);
        cmd.Parameters.AddWithValue("@unm", TextBox1.Text);
        cmd.Parameters.AddWithValue("@uc", TextBox2.Text);
        cmd.Parameters.AddWithValue("@em", TextBox3.Text);
        cmd.Parameters.AddWithValue("@um", TextBox4.Text);

        cmd.ExecuteNonQuery();
        Label1.Text = "Record Added Successfully";
    }
}